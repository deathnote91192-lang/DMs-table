# DM’s Table

A desktop toolkit for running tabletop RPG campaigns (built around D&D 5e). Generate NPCs, settlements, shops, guilds and maps, link them into a living campaign, build characters, and share what you choose with your players over the local network.

Runs on Linux (AppImage) and Windows (portable exe). Built with Electron. Everything is stored locally on your machine.

## Features

- **NPCs**: names by race and sex, personality sketch, 5e-style stat blocks, levels 1 to 20 or Legendary (stats up to 30). Rename and edit any stat.
- **Settlements**: a sheet in the style of a character sheet (military, commerce, industry, education, agriculture, culture), with districts, buildings, factions and key NPCs.
- **Linked campaign**: add NPCs, guilds and shops to a town, members to a guild, and pin towns on a world map.
- **Shops and guilds**: 13 store types and 25 guild types with owners, goals, ranks, rivals, secrets and hooks.
- **Maps**: world maps and city maps drawn from a seed, saved as images.
- **Characters**: point buy with an adjustable point total, gestalt leveling, multiple subclasses, feats, and species, classes and subclasses from many books (names and the numbers the builder needs, not rules text).
- **Custom items**: weapon type, dice, damage type, magic bonus and 0 to 5 rune slots.
- **Players**: a party tracker with HP, PDF character sheet import (fillable PDFs), and a Content tab to choose your books and add your own entries.
- **Play**: players join from a browser on your network with a code you choose. You decide what each player or the whole party sees.
- **Updates**: the app checks a feed on GitHub Releases and installs new versions in place.

## Download

Get the latest AppImage or portable exe from the [Releases](https://github.com/OWNER/REPO/releases) page.

- Linux: `chmod +x DMs-Table-*.AppImage && ./DMs-Table-*.AppImage` (needs `libfuse2` on some distros, or run with `--appimage-extract-and-run`).
- Windows: run the portable exe. The apps are unsigned, so SmartScreen may warn: choose **More info**, then **Run anyway**.

## Build from source

```bash
npm install
npm start                       # run in development
npx electron-builder --linux --win
```

Building the Windows exe from Linux needs Wine (the release workflow uses a Docker image that has it).

## Releases and updates

1. Run `node set-repo.js OWNER/REPO` once and commit the change. This sets the default update feed.
2. Tag a version: `git tag v1.9.0 && git push --tags`.
3. The workflow in `.github/workflows/release.yml` builds both apps, writes `latest.json` with SHA-512 checksums, and attaches everything to the release.
4. Installed apps pick it up from the Updates tab (feed address: `https://github.com/OWNER/REPO/releases/latest/download/latest.json`).

For a manual release, build, run `node make-manifest.js <download-base-url>`, and upload the AppImage, the exe and `dist/latest.json` to any HTTPS host.

## Hosting players

Open the **Play** tab, choose a code, and start hosting. Players open the address shown in a browser on the same network and enter the code and a name. The connection is plain HTTP on your local network: keep the code private and stop hosting when you are done. Nothing is reachable from the internet unless you forward the port yourself.

## Content and trademarks

DM’s Table is an unofficial fan-made tool. It is not affiliated with or endorsed by Wizards of the Coast or any publisher. Dungeons & Dragons and related names are trademarks of their owners. The app contains names of classes, subclasses, species and feats for compatibility, plus the few numbers the character builder needs. It does not include book text, and it does not read or redistribute copyrighted books. Use the Content tab to add material from books you own.

## License

Code: [MIT](LICENSE). Bundled fonts (Alegreya and Almendra) are under the SIL Open Font License; see `fonts/`.
