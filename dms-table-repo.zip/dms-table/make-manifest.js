// Usage: node make-manifest.js <base-download-url> [release notes]
// Run after "npx electron-builder --linux --win". Writes dist/latest.json (the update feed).
const fs=require("fs"),c=require("crypto"),v=require("./package.json").version,[,,base,notes=""]=process.argv;
if(!base){console.log("usage: node make-manifest.js https://host/path/ [notes]");process.exit(1)}
const h=f=>c.createHash("sha512").update(fs.readFileSync("dist/"+f)).digest("hex"),u=f=>base.replace(/\/?$/,"/")+encodeURIComponent(f);
const L=`DMs-Table-${v}-x86_64.AppImage`,W=`DMs-Table-${v}-portable.exe`;
fs.writeFileSync("dist/latest.json",JSON.stringify({version:v,notes,linux:{url:u(L),sha512:h(L)},win:{url:u(W),sha512:h(W)}},null,2));
console.log("wrote dist/latest.json for "+v);
