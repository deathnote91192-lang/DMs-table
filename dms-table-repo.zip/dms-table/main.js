const {app,BrowserWindow,Menu,shell,ipcMain,dialog}=require("electron");
const fs=require("fs"),path=require("path"),crypto=require("crypto"),{spawn}=require("child_process");
if(process.platform==="linux")app.commandLine.appendSwitch("no-sandbox");
const cfg=()=>path.join(app.getPath("userData"),"update.json");
const getUrl=()=>{try{return JSON.parse(fs.readFileSync(cfg(),"utf8")).url||""}catch(e){return require("./package.json").updateUrl||""}};
const num=v=>String(v).split(".").map(n=>parseInt(n)||0);
const newer=(a,b)=>{const x=num(a),y=num(b);for(let i=0;i<3;i++)if((x[i]||0)!==(y[i]||0))return(x[i]||0)>(y[i]||0);return false};
const https=u=>/^https:\/\//i.test(u);
const selfPath=()=>process.platform==="win32"?process.env.PORTABLE_EXECUTABLE_FILE:process.env.APPIMAGE;
let found=null,win;
ipcMain.handle("upd:info",()=>({version:app.getVersion(),url:getUrl(),canSelfUpdate:!!selfPath()}));
ipcMain.handle("upd:setUrl",(e,u)=>{u=String(u||"").trim();if(u&&!https(u))return{error:"The feed address must start with https://"};fs.writeFileSync(cfg(),JSON.stringify({url:u}));return{ok:true}});
ipcMain.handle("upd:check",async()=>{
  const url=getUrl();if(!url)return{error:"Enter an update feed address first."};
  try{
    const r=await fetch(url,{cache:"no-store"});if(!r.ok)return{error:"The feed returned HTTP "+r.status+"."};
    const m=await r.json(),asset=process.platform==="win32"?m.win:m.linux;
    if(!m.version)return{error:"The feed has no version number."};
    if(!newer(m.version,app.getVersion()))return{upToDate:true};
    if(!asset||!https(asset.url)||!asset.sha512)return{error:"The feed has no valid download for this system."};
    found={version:m.version,asset};return{available:true,version:m.version,notes:m.notes||""};
  }catch(e){return{error:"Could not reach the feed: "+e.message}}});
ipcMain.handle("upd:install",async()=>{
  if(!found)return{error:"Check for updates first."};
  const self=selfPath();
  if(!self){shell.openExternal(found.asset.url);return{opened:true}}
  const tmp=self+".update";
  try{
    const r=await fetch(found.asset.url);if(!r.ok)throw new Error("Download failed (HTTP "+r.status+").");
    const total=+r.headers.get("content-length")||0,h=crypto.createHash("sha512"),out=fs.createWriteStream(tmp);let got=0;
    for await(const c of r.body){h.update(c);got+=c.length;if(!out.write(c))await new Promise(f=>out.once("drain",f));win.webContents.send("upd:progress",total?got/total:0)}
    await new Promise((f,j)=>out.end(e=>e?j(e):f()));
    if(h.digest("hex")!==String(found.asset.sha512).toLowerCase())throw new Error("Checksum mismatch, so the download was discarded.");
    if(process.platform==="linux"){fs.chmodSync(tmp,0o755);fs.renameSync(tmp,self);spawn(self,[],{detached:true,stdio:"ignore"}).unref()}
    else spawn("cmd.exe",["/c",`ping -n 4 127.0.0.1 >nul & move /y "${tmp}" "${self}" & start "" "${self}"`],{detached:true,stdio:"ignore",windowsVerbatimArguments:true}).unref();
    setTimeout(()=>app.quit(),300);return{ok:true};
  }catch(e){try{fs.unlinkSync(tmp)}catch(_){}return{error:e.message}}});
const host=require("./server")(),hcfg=()=>path.join(app.getPath("userData"),"host.json");
const hload=()=>{try{return JSON.parse(fs.readFileSync(hcfg(),"utf8"))}catch(e){return{}}},hsave=c=>fs.writeFileSync(hcfg(),JSON.stringify(c));
const rnd=()=>Array.from(crypto.randomBytes(5),b=>"ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[b%32]).join(""),badCode=c=>c.length<4||c.length>32;
ipcMain.handle("srv:status",()=>{const c=hload();if(!c.code){c.code=rnd();hsave(c)}return{...host.status(),code:c.code,cfgPort:c.port||4777}});
ipcMain.handle("srv:start",async(e,p,c)=>{p=+p;c=String(c||"").trim();if(!(p>=1024&&p<=65535))return{error:"The port must be between 1024 and 65535."};if(badCode(c))return{error:"The code must be 4 to 32 characters."};
try{await host.start(p,c);hsave({code:c,port:p});return host.status()}catch(err){return{error:err.code==="EADDRINUSE"?"That port is already in use. Try another.":err.message}}});
ipcMain.handle("srv:stop",()=>{host.stop();return host.status()});
ipcMain.handle("srv:code",(e,c)=>{c=String(c||"").trim();if(badCode(c))return{error:"The code must be 4 to 32 characters."};host.setCode(c);hsave({...hload(),code:c});return{ok:true}});
ipcMain.handle("srv:pub",(e,l,css)=>{host.publish(l,css);return{ok:true}});
ipcMain.handle("srv:kick",(e,n)=>{host.kick(String(n));return{ok:true}});
ipcMain.handle("pdf:import",async()=>{const r=await dialog.showOpenDialog(win,{title:"Import character sheet",filters:[{name:"PDF",extensions:["pdf"]}],properties:["openFile"]});if(r.canceled||!r.filePaths[0])return{canceled:true};
const f=r.filePaths[0];try{if(fs.statSync(f).size>20e6)return{error:"That PDF is over 20 MB."};return{file:path.basename(f),fields:await require("./pdfimport")(fs.readFileSync(f))}}catch(err){return{error:"Could not read that PDF: "+err.message}}});
app.on("before-quit",()=>host.stop());
app.whenReady().then(()=>{
  Menu.setApplicationMenu(null);
  win=new BrowserWindow({width:1100,height:850,title:"DM’s Table",icon:path.join(__dirname,"icon.png"),autoHideMenuBar:true,webPreferences:{contextIsolation:true,nodeIntegration:false,preload:path.join(__dirname,"preload.js")}});
  win.loadFile("index.html");host.onChange(()=>{if(!win.isDestroyed())win.webContents.send("srv:players",host.players())});setInterval(()=>{if(!win.isDestroyed()&&host.status().running)win.webContents.send("srv:players",host.players())},5000);
  win.webContents.setWindowOpenHandler(({url})=>{if(https(url))shell.openExternal(url);return{action:"deny"}});
});
app.on("window-all-closed",()=>app.quit());
