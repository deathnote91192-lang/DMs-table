// Usage: node set-repo.js OWNER/REPO
// Points the app's default update feed (and the README links) at your GitHub repository.
const fs=require("fs"),r=process.argv[2];
if(!/^[\w.-]+\/[\w.-]+$/.test(r||"")){console.log("usage: node set-repo.js OWNER/REPO");process.exit(1)}
const p=JSON.parse(fs.readFileSync("package.json","utf8"));
p.repository={type:"git",url:`git+https://github.com/${r}.git`};p.homepage=`https://github.com/${r}`;
p.updateUrl=`https://github.com/${r}/releases/latest/download/latest.json`;
fs.writeFileSync("package.json",JSON.stringify(p,null,1)+"\n");
fs.writeFileSync("README.md",fs.readFileSync("README.md","utf8").replace(/OWNER\/REPO/g,r));
console.log("Repository set to "+r+". Commit the change, then tag a release (git tag v1.8.0 && git push --tags).");
