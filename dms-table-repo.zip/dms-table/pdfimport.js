// Reads the form fields of a fillable PDF character sheet (official 5e sheets, D&D Beyond exports).
const {PDFDocument}=require("pdf-lib");
module.exports=async bytes=>{const doc=await PDFDocument.load(bytes,{ignoreEncryption:true,updateMetadata:false}),out=[];
for(const f of doc.getForm().getFields().slice(0,800)){let v=null;try{if(f.getText)v=f.getText();else if(f.getSelected)v=[].concat(f.getSelected()).join(", ");else if(f.isChecked)v=f.isChecked()?"yes":""}catch(e){}out.push({n:f.getName(),v})}
return out};
