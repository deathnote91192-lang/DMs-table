const {contextBridge,ipcRenderer}=require("electron");
contextBridge.exposeInMainWorld("dmUpdater",{
  info:()=>ipcRenderer.invoke("upd:info"),
  setUrl:u=>ipcRenderer.invoke("upd:setUrl",u),
  check:()=>ipcRenderer.invoke("upd:check"),
  install:()=>ipcRenderer.invoke("upd:install"),
  onProgress:cb=>ipcRenderer.on("upd:progress",(_,p)=>cb(p))
});
contextBridge.exposeInMainWorld("dmHost",{status:()=>ipcRenderer.invoke("srv:status"),start:(p,c)=>ipcRenderer.invoke("srv:start",p,c),stop:()=>ipcRenderer.invoke("srv:stop"),setCode:c=>ipcRenderer.invoke("srv:code",c),publish:(l,c)=>ipcRenderer.invoke("srv:pub",l,c),kick:n=>ipcRenderer.invoke("srv:kick",n),onPlayers:cb=>ipcRenderer.on("srv:players",(_,l)=>cb(l))});
contextBridge.exposeInMainWorld("dmPdf",{import:()=>ipcRenderer.invoke("pdf:import")});
