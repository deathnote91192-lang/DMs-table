// LAN join server: players open the page in a browser, enter the DM's code and a name,
// and see only the items the DM shared with the whole party or with them.
const http=require("http"),crypto=require("crypto"),os=require("os");
module.exports=function(){
let srv=null,code="",items=[],css="",port=0,rev=0,onch=()=>{};const sess=new Map(),fails=new Map();
const sha=s=>crypto.createHash("sha256").update(String(s)).digest(),same=(a,b)=>crypto.timingSafeEqual(sha(a),sha(b));
const clean=n=>String(n||"").replace(/[^\p{L}\p{N} _'’-]/gu,"").replace(/\s+/g," ").trim().slice(0,24),lc=s=>String(s).toLowerCase(),now=()=>Date.now();
const players=()=>{for(const[t,s]of sess)if(now()-s.seen>12*36e5)sess.delete(t);return[...sess.values()].filter(s=>now()-s.seen<20e3).map(s=>s.name)};
const vis=s=>items.filter(i=>i.aud==="party"||(String(i.aud).startsWith("p:")&&lc(i.aud.slice(2))===lc(s.name)));
const page=(c,n)=>`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DM’s Table</title><style>${c}</style></head><body><div class="wrap"><h1>DM’s Table</h1>
<div id="join" class="card"><label>Join code<input id="c" autocomplete="off"></label><label>Your name<input id="n" maxlength="24" autocomplete="off"></label><p><button class="btn" id="go">Join</button></p><p id="e" class="mut"></p></div>
<div id="live" hidden><p class="mut"><span id="who"></span> <button class="btn alt" id="lv">Leave</button></p><p id="pl" class="mut"></p><div id="feed"></div></div></div>
<script nonce="${n}">
const $=s=>document.querySelector(s);let tok=sessionStorage.getItem("t");
async function api(p,b){const r=await fetch(p,b?{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)}:{});return{s:r.status,j:await r.json().catch(()=>({}))}}
function show(){$("#join").hidden=!!tok;$("#live").hidden=!tok}
async function poll(){if(!tok)return;const r=await api("/api/feed?token="+encodeURIComponent(tok));if(r.s===401){tok=null;sessionStorage.removeItem("t");show();return}
$("#who").textContent="Joined as "+r.j.name;$("#pl").textContent="At the table: "+r.j.players.join(", ");
const f=$("#feed");if(f.dataset.r!==String(r.j.rev)){f.innerHTML=r.j.items.map(i=>i.html).join("")||'<p class="mut">Nothing has been shared with you yet. Your DM will share items here.</p>';f.dataset.r=r.j.rev}}
$("#go").onclick=async()=>{const r=await api("/api/join",{code:$("#c").value.trim(),name:$("#n").value});if(r.s!==200){$("#e").textContent=r.j.error||"Could not join.";return}tok=r.j.token;sessionStorage.setItem("t",tok);$("#e").textContent="";show();poll()};
$("#lv").onclick=async()=>{await api("/api/leave",{token:tok});tok=null;sessionStorage.removeItem("t");show()};
show();poll();setInterval(poll,3000);
</script></body></html>`;
const h=(req,res)=>{const ip=req.socket.remoteAddress,u=new URL(req.url,"http://x");
const send=(c,o,ct="application/json",ex={})=>{res.writeHead(c,{"Content-Type":ct+"; charset=utf-8","Cache-Control":"no-store","X-Content-Type-Options":"nosniff",...ex});res.end(typeof o==="string"?o:JSON.stringify(o))};
if(req.method==="GET"&&u.pathname==="/"){const n=crypto.randomBytes(16).toString("base64");return send(200,page(css,n),"text/html",{"Content-Security-Policy":`default-src 'none'; script-src 'nonce-${n}'; style-src 'unsafe-inline'; img-src data:; connect-src 'self'; base-uri 'none'; form-action 'none'`,"X-Frame-Options":"DENY"})}
if(req.method==="GET"&&u.pathname==="/api/feed"){const s=sess.get(u.searchParams.get("token")||"");if(!s)return send(401,{error:"expired"});s.seen=now();return send(200,{name:s.name,rev,items:vis(s).map(i=>({id:i.id,html:i.html})),players:players()})}
if(req.method==="POST"){let b="";req.on("data",d=>{b+=d;if(b.length>4096)req.destroy()});req.on("end",()=>{let j={};try{j=JSON.parse(b)}catch(e){}
if(u.pathname==="/api/join"){const f=fails.get(ip)||{n:0,t:now()};if(now()-f.t>3e5){f.n=0;f.t=now()}
if(f.n>=8)return send(429,{error:"Too many attempts. Wait a few minutes."});
if(!code||!same(j.code||"",code)){f.n++;fails.set(ip,f);return send(403,{error:"Wrong code."})}
const name=clean(j.name);if(!name)return send(400,{error:"Enter a name."});
for(const[t,s]of sess)if(lc(s.name)===lc(name))sess.delete(t);
const token=crypto.randomBytes(24).toString("hex");sess.set(token,{name,seen:now()});onch();return send(200,{token,name})}
if(u.pathname==="/api/leave"){sess.delete(j.token);onch();return send(200,{ok:1})}
send(404,{error:"Not found"})});return}
send(404,{error:"Not found"})};
function stop(){if(srv){srv.close();if(srv.closeAllConnections)srv.closeAllConnections();srv=null}sess.clear();onch()}
return{
start(p,c){return new Promise((ok,no)=>{stop();code=c;const s=http.createServer(h);s.once("error",e=>no(e));s.listen(p,"0.0.0.0",()=>{srv=s;port=s.address().port;ok(port)})})},
stop,setCode(c){code=c;sess.clear();onch()},kick(n){for(const[t,s]of sess)if(lc(s.name)===lc(n))sess.delete(t);onch()},
publish(l,c){items=(Array.isArray(l)?l:[]).slice(0,400).map(i=>({id:String(i.id),aud:String(i.aud),html:String(i.html).slice(0,4e6)}));if(typeof c==="string")css=c.slice(0,60000);rev++},
players,onChange(f){onch=f},
status(){return{running:!!srv,port,players:players(),urls:srv?Object.values(os.networkInterfaces()).flat().filter(i=>i&&i.family==="IPv4"&&!i.internal).map(i=>`http://${i.address}:${port}`):[]}}}};
